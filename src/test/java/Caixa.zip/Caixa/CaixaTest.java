package Caixa;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import sexta_aula_ExercicioConta.Caixa;
import sexta_aula_ExercicioConta.Conta;
import sexta_aula_ExercicioConta.ContaEspecial;
import sexta_aula_ExercicioConta.ContaUniversitaria;

public class CaixaTest {
	List<Conta> contas = new ArrayList<Conta>();

	@BeforeEach
	public void init() {
		contas.add(new Conta());
		contas.add(new ContaEspecial());
		contas.add(new ContaUniversitaria());

	}

	@Test
	@DisplayName("Teste para depositar")
	public void testDeposito() {
		Conta conta = new Conta();
		conta.deposito(10);

		Caixa.deposito(conta, 20);

		assertEquals(30, conta.getSaldo());
	}

	@Test
	@DisplayName("Teste para saque")
	public void testSaque() {
		Conta conta = new Conta();
		conta.deposito(30);

		Caixa.saque(conta, 20);

		assertEquals(10, conta.getSaldo());
	}
	
	@Test
	@DisplayName("Teste para transferencia")
	public void testTransferencia() {
		Conta conta = new Conta();
		Conta conta2 = new Conta();
		conta.deposito(30);
		conta2.deposito(30);

		Caixa.transferencia(conta, conta2, 20);;

		assertEquals(50, conta2.getSaldo());
	}
	
	@Test
	@DisplayName("Teste para saque em ContaEspecial com saldo dentro do limite")
	public void testSaqueDentroDoLimite() {
		ContaEspecial conta = new ContaEspecial();
		conta.deposito(500);
		conta.setLimite(1500);
		
		Caixa.saque(conta, 500);
		
		assertEquals(1000,conta.getSaldo());
	}
	
	@Test
	@DisplayName("Teste para saque em ContaEspecial com saldo fora do limite")
	public void testSaqueForaDoLimite() {
		ContaEspecial conta = new ContaEspecial();
		conta.deposito(500);
		conta.setLimite(600);
		
		Caixa.saque(conta, 700);
		
		assertEquals(500,conta.getSaldo());
	}
	
	@Test
	@DisplayName("Teste para saque em ContaUniversditaria com saldo dentro do limite")
	public void testSaqueUniversitarioDentroDoLimite() {
		ContaUniversitaria conta = new ContaUniversitaria();
		conta.deposito(500);
		
		Caixa.deposito(conta, 500);
		
		assertEquals(1000,conta.getSaldo());
	}
	
	@Test
	@DisplayName("Teste para saque em ContaUniversditaria com saldo fora do limite")
	public void testSaqueUniversitarioForaDoLimite() {
		ContaUniversitaria conta = new ContaUniversitaria();
		conta.deposito(500);
		
		Caixa.deposito(conta, 2100);
		
		assertEquals(500,conta.getSaldo());
	}
	
	@Test
	@DisplayName("Teste para obter saldo da Conta")
	public void testGetSaldo() {
	    Conta conta = new Conta();
	    conta.deposito(100);
	    
	    double saldo = conta.getSaldo();
	    
	    assertEquals(100, saldo);
	}
	
	@Test
	@DisplayName("Teste para definir limite em ContaEspecial")
	public void testSetLimite() {
	    ContaEspecial conta = new ContaEspecial();
	    conta.setLimite(1500);

	    assertEquals(1500, conta.getLimite());
	}

	
	@Test
	@DisplayName("Teste para execução de operações no Caixa")
	public void testExecutarOperacoes() {
		Conta conta1 = new Conta();
		conta1.deposito(100);
		ContaEspecial conta2 = new ContaEspecial();
		conta2.deposito(50);
		ContaUniversitaria conta3 = new ContaUniversitaria();
		conta3.deposito(100);

		Caixa.deposito(conta1, 100);
		Caixa.saque(conta2, 50);
		Caixa.transferencia(conta3, conta1, 100);
		
		assertEquals(300, conta1.getSaldo());
		assertEquals(50, conta2.getSaldo());
		assertEquals(0, conta3.getSaldo());


	}

}
